package com.saif.assignment2;

public class UnaryDemo {

	public static void main(String[] args) {
		int x = -20;
		int result;
		
		result = +x;
		System.out.println("Result : "+ result);
		
		result = -x;
		System.out.println("Result : "+ result);
	}
}
