package com.saif.assignment2;

public class FactorialofNumber7Ques8 {

	public static void main(String[] args) {
		
		int number = 7;
		int factorial = 1;
		for (int i=1; i<= number; i++){
			factorial= factorial*i;
	   }
		System.out.printf("Factorial of 7 is: "+ factorial);{
    }
}
}