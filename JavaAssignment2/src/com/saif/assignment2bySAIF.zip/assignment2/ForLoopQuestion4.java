package com.saif.assignment2;

public class ForLoopQuestion4 {

	
	public static void main(String[] args) {
		
			for(int i=1; i<=500; i=i*2) {
				
				System.out.println(i);
				
			}
		}
	}

