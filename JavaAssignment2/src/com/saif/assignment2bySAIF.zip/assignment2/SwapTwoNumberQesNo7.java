package com.saif.assignment2;

public class SwapTwoNumberQesNo7 {
	public static void main(String[] args) {
		
        int x = 25; 
        int y = 30; 
        x = x + y; 
        y = x - y; 
        x = x - y; 
        System.out.println("After swaping:"
                           + " x = " + x + ", y = " + y); 
    } 
} 
  

