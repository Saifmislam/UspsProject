package com.saif.assignment2;

public class SwapTwoNumberQesNo7WithThirdVariable {

	public static void main(String[] args) {
		int x = 25; 
        int y = 30; 
        int temp = x;
        x = y; 
        y = temp; 
        
        System.out.println("After swaping:"
                           + " x = " + x + ", y = " + y); 
	}

}
