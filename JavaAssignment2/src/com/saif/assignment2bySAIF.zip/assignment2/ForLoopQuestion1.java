package com.saif.assignment2;

public class ForLoopQuestion1 {

 public static void main(String[] args) {
		
		for(int i=50; i>=1; i-- ) {
			System.out.print(i + " ");
			
		}
	}
 }



