package com.saif.assignment2;

public class MultiplicationTableOf8Queston5 {


	    public static void main(String[] args) {

	        int num = 8;
	        for(int i = 1; i <= 10; ++i){
	            System.out.printf("%d * %d = %d \n", num, i, num * i);
	        }
	    }
	}
