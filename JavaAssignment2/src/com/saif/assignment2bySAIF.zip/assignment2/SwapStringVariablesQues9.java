package com.saif.assignment2;

public class SwapStringVariablesQues9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x = "Talen"; 
        String y = "Tech"; 
        String temp = x;
        x = y; 
        y = temp;
        
        System.out.println("After swaping:"
                           + " x = " + x + ", y = " + y); 
	}
	

}
