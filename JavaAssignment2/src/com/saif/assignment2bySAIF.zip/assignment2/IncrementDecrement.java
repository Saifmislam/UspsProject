package com.saif.assignment2;

public class IncrementDecrement {

	public static void main(String[] args) {
	int x = 30;
	int y;
	
	y = x--;// y=30
	System.out.println("Y : "+y);
	
	y = x; // y= 29
	System.out.println("Y : "+y);
	
	
	
	}
}
